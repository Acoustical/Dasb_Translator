# Dasb_Translator
A CLI translation tool by reading the clipboard
